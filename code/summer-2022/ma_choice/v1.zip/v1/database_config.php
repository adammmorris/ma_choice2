<?php
  $servername = "localhost";
  $port = 3306;
  $username = "amorris";
  $password = "oSant3ria_11";
  $dbname = "amorris";
?>